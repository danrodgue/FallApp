// Configuración global para frontend (punto único para cambiar la URL del backend)
// Intenta cargar `../config.json` (archivo local con credenciales), si está disponible.
(function(){
  let cfg = null;
  try {
    // En renderer con nodeIntegration=true se puede usar require para leer archivos JSON
    // El archivo real se encuentra en js/config.json
    cfg = require('./config.json');
  } catch (e) {
    cfg = null;
  }

  const defaultBase = 'http://35.180.21.42:8080';
  const apiBase = (cfg && cfg.apiBase) ? cfg.apiBase : defaultBase;

  window._API_BASE = window._API_BASE || apiBase;
  // Endpoints usados por los scripts
  window._API_URL = window._API_URL || (window._API_BASE + '/api');
  window._recurso = window._recurso || (window._API_BASE + '/api/fallas');
  window._eventsResource = window._eventsResource || (window._API_BASE + '/api/events');
  window._authEndpoint = window._authEndpoint || (window._API_BASE + '/api/auth/login');

  // Credenciales (si están en config.json). Evita imprimirlas en consola.
  if (cfg && cfg.apiUser) {
    window._API_CREDENTIALS = {
      user: cfg.apiUser,
      pass: cfg.apiPassword || ''
    };
  } else {
    window._API_CREDENTIALS = window._API_CREDENTIALS || { user: '', pass: '' };
  }
})();
